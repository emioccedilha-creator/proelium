@echo off
chcp 65001 >nul
cd /d "%~dp0"
"%~dp0runtime\node.exe" --use-env-proxy "%~dp0desktop\server.mjs"
if errorlevel 1 pause
